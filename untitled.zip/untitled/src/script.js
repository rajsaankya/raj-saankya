let resumeText = "";

// Skills
const roleSkills = {
  "AI Engineer": ["python","machine learning","tensorflow"],
  "Prompt Engineer": ["ai","prompt","chatgpt"],
  "Data Scientist": ["python","statistics","pandas"],
  "Cloud Engineer": ["aws","cloud","docker"],
  "Cyber Security Analyst": ["security","network"],
  "Full Stack Developer": ["html","css","javascript","react"]
};

// Job Data
const jobData = {
  "AI Engineer": { openings:"22,000+", companies:["Google","Microsoft"] },
  "Prompt Engineer": { openings:"12,000+", companies:["OpenAI","Startups"] },
  "Data Scientist": { openings:"40,000+", companies:["Amazon","Infosys"] },
  "Cloud Engineer": { openings:"30,000+", companies:["AWS","Azure"] },
  "Cyber Security Analyst": { openings:"25,000+", companies:["IBM","Cisco"] },
  "Full Stack Developer": { openings:"50,000+", companies:["Flipkart","Zoho"] }
};

// Slide
function showSlide(id){
  document.querySelectorAll(".slide").forEach(s=>s.classList.remove("active"));
  document.getElementById(id).classList.add("active");
}

// STEP 1
async function goToAnalysis(){

  let file = document.getElementById("resumeFile").files[0];
  let role = document.getElementById("jobRole").value;

  if(!file || role===""){
    alert("Upload resume & select role");
    return;
  }

  document.getElementById("selectedRole").innerText = role;

  let reader = new FileReader();

  reader.onload = async function(){

    let typedArray = new Uint8Array(this.result);
    let pdf = await pdfjsLib.getDocument(typedArray).promise;

    let text = "";

    for(let i=1;i<=pdf.numPages;i++){
      let page = await pdf.getPage(i);
      let content = await page.getTextContent();
      text += content.items.map(i=>i.str).join(" ");
    }

    resumeText = text.toLowerCase();

    analyze(role);
  };

  reader.readAsArrayBuffer(file);
}

// ANALYSIS
function analyze(role){

  let required = roleSkills[role];

  let detected = [];
  let missing = [];

  required.forEach(skill=>{
    if(resumeText.includes(skill)) detected.push(skill);
    else missing.push(skill);
  });

  let score = Math.floor((detected.length/required.length)*100);
  document.getElementById("score").innerText = score;

  document.getElementById("detected").innerHTML =
    detected.map(s=>`<span class="skill">${s}</span>`).join("");

  document.getElementById("missing").innerHTML =
    missing.map(s=>`<span class="skill missing">${s}</span>`).join("");

  document.getElementById("upgrade").innerHTML =
    missing.map(s=>`<span class="skill missing">${s}</span>`).join("");

  let suggested = getSuggested();
  document.getElementById("suggested").innerText = suggested;

  renderGraph(score);

  showSlide("slide2");
}

// Graph
function renderGraph(score){
  document.getElementById("chart").innerHTML = `
    <div class="bar-bg">
      <div class="bar-fill" style="width:${score}%"></div>
    </div>
    <p>Score: ${score}%</p>
  `;
}

// Suggested Role
function getSuggested(){

  if(resumeText.includes("machine learning")) return "AI Engineer";
  if(resumeText.includes("prompt")) return "Prompt Engineer";
  if(resumeText.includes("cloud")) return "Cloud Engineer";
  if(resumeText.includes("security")) return "Cyber Security Analyst";
  if(resumeText.includes("react")) return "Full Stack Developer";

  return "Data Scientist";
}

// Job Card
function createCard(role){

  let d = jobData[role];

  return `
    <div class="job-card">
      <p><b>${role}</b></p>
      <p>Openings: ${d.openings}</p>
      <p>Companies: ${d.companies.join(", ")}</p>
    </div>
  `;
}

// FINAL SLIDE
function showFinal(){

  let selected = document.getElementById("jobRole").value;
  let suggested = getSuggested();

  document.getElementById("finalSelected").innerHTML =
    createCard(selected);

  document.getElementById("finalSuggested").innerHTML =
    createCard(suggested);

  showSlide("slide3");
}

// Restart
function restart(){
  showSlide("slide1");
}